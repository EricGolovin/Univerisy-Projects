﻿
namespace CourseWork_Atelie
{
    partial class SummaryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.nameGroupBox = new System.Windows.Forms.GroupBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.modelNameGroupBox = new System.Windows.Forms.GroupBox();
            this.modelNameTextBox = new System.Windows.Forms.TextBox();
            this.bookingSumGroupBox = new System.Windows.Forms.GroupBox();
            this.bookingSumTextBox = new System.Windows.Forms.TextBox();
            this.orderDateGroupBox = new System.Windows.Forms.GroupBox();
            this.orderDateTextBox = new System.Windows.Forms.TextBox();
            this.fabricNameGroupBox = new System.Windows.Forms.GroupBox();
            this.fabricNameTextBox = new System.Windows.Forms.TextBox();
            this.finishButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.fabricPictureLabel = new System.Windows.Forms.Label();
            this.fabricPictureBox = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.modelPictureLabel = new System.Windows.Forms.Label();
            this.modelPictureBox = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.nameGroupBox.SuspendLayout();
            this.modelNameGroupBox.SuspendLayout();
            this.bookingSumGroupBox.SuspendLayout();
            this.orderDateGroupBox.SuspendLayout();
            this.fabricNameGroupBox.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fabricPictureBox)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.modelPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.Controls.Add(this.nameGroupBox, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.modelNameGroupBox, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.bookingSumGroupBox, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.orderDateGroupBox, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.fabricNameGroupBox, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.finishButton, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 6);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 9;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1178, 744);
            this.tableLayoutPanel1.TabIndex = 1;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // nameGroupBox
            // 
            this.nameGroupBox.AutoSize = true;
            this.nameGroupBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.nameGroupBox.Controls.Add(this.nameTextBox);
            this.nameGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nameGroupBox.Location = new System.Drawing.Point(128, 210);
            this.nameGroupBox.Name = "nameGroupBox";
            this.nameGroupBox.Size = new System.Drawing.Size(394, 59);
            this.nameGroupBox.TabIndex = 0;
            this.nameGroupBox.TabStop = false;
            this.nameGroupBox.Text = "Name";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nameTextBox.Location = new System.Drawing.Point(3, 22);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(388, 26);
            this.nameTextBox.TabIndex = 0;
            this.nameTextBox.TextChanged += new System.EventHandler(this.nameTextBox_TextChanged);
            // 
            // modelNameGroupBox
            // 
            this.modelNameGroupBox.AutoSize = true;
            this.modelNameGroupBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.modelNameGroupBox.Controls.Add(this.modelNameTextBox);
            this.modelNameGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.modelNameGroupBox.Location = new System.Drawing.Point(128, 305);
            this.modelNameGroupBox.Name = "modelNameGroupBox";
            this.modelNameGroupBox.Size = new System.Drawing.Size(394, 59);
            this.modelNameGroupBox.TabIndex = 1;
            this.modelNameGroupBox.TabStop = false;
            this.modelNameGroupBox.Text = "Model Name";
            // 
            // modelNameTextBox
            // 
            this.modelNameTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.modelNameTextBox.Location = new System.Drawing.Point(3, 22);
            this.modelNameTextBox.Name = "modelNameTextBox";
            this.modelNameTextBox.Size = new System.Drawing.Size(388, 26);
            this.modelNameTextBox.TabIndex = 0;
            this.modelNameTextBox.TextChanged += new System.EventHandler(this.modelNameTextBox_TextChanged);
            // 
            // bookingSumGroupBox
            // 
            this.bookingSumGroupBox.AutoSize = true;
            this.bookingSumGroupBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bookingSumGroupBox.Controls.Add(this.bookingSumTextBox);
            this.bookingSumGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookingSumGroupBox.Location = new System.Drawing.Point(128, 400);
            this.bookingSumGroupBox.Name = "bookingSumGroupBox";
            this.bookingSumGroupBox.Size = new System.Drawing.Size(394, 59);
            this.bookingSumGroupBox.TabIndex = 2;
            this.bookingSumGroupBox.TabStop = false;
            this.bookingSumGroupBox.Text = "Booking Sum";
            // 
            // bookingSumTextBox
            // 
            this.bookingSumTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bookingSumTextBox.Location = new System.Drawing.Point(3, 22);
            this.bookingSumTextBox.Name = "bookingSumTextBox";
            this.bookingSumTextBox.Size = new System.Drawing.Size(388, 26);
            this.bookingSumTextBox.TabIndex = 0;
            this.bookingSumTextBox.TextChanged += new System.EventHandler(this.bookingSumTextBox_TextChanged);
            // 
            // orderDateGroupBox
            // 
            this.orderDateGroupBox.AutoSize = true;
            this.orderDateGroupBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.orderDateGroupBox.Controls.Add(this.orderDateTextBox);
            this.orderDateGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.orderDateGroupBox.Location = new System.Drawing.Point(654, 210);
            this.orderDateGroupBox.Name = "orderDateGroupBox";
            this.orderDateGroupBox.Size = new System.Drawing.Size(394, 59);
            this.orderDateGroupBox.TabIndex = 3;
            this.orderDateGroupBox.TabStop = false;
            this.orderDateGroupBox.Text = "Order Date";
            // 
            // orderDateTextBox
            // 
            this.orderDateTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.orderDateTextBox.Location = new System.Drawing.Point(3, 22);
            this.orderDateTextBox.Name = "orderDateTextBox";
            this.orderDateTextBox.Size = new System.Drawing.Size(388, 26);
            this.orderDateTextBox.TabIndex = 0;
            this.orderDateTextBox.TextChanged += new System.EventHandler(this.orderDateTextBox_TextChanged);
            // 
            // fabricNameGroupBox
            // 
            this.fabricNameGroupBox.AutoSize = true;
            this.fabricNameGroupBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.fabricNameGroupBox.Controls.Add(this.fabricNameTextBox);
            this.fabricNameGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fabricNameGroupBox.Location = new System.Drawing.Point(654, 305);
            this.fabricNameGroupBox.Name = "fabricNameGroupBox";
            this.fabricNameGroupBox.Size = new System.Drawing.Size(394, 59);
            this.fabricNameGroupBox.TabIndex = 4;
            this.fabricNameGroupBox.TabStop = false;
            this.fabricNameGroupBox.Text = "Fabric Name";
            // 
            // fabricNameTextBox
            // 
            this.fabricNameTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fabricNameTextBox.Location = new System.Drawing.Point(3, 22);
            this.fabricNameTextBox.Name = "fabricNameTextBox";
            this.fabricNameTextBox.Size = new System.Drawing.Size(388, 26);
            this.fabricNameTextBox.TabIndex = 0;
            this.fabricNameTextBox.TextChanged += new System.EventHandler(this.fabricNameTextBox_TextChanged);
            // 
            // finishButton
            // 
            this.finishButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.finishButton.AutoSize = true;
            this.finishButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.finishButton.Location = new System.Drawing.Point(528, 672);
            this.finishButton.Name = "finishButton";
            this.finishButton.Size = new System.Drawing.Size(120, 59);
            this.finishButton.TabIndex = 5;
            this.finishButton.Text = "Finish";
            this.finishButton.UseVisualStyleBackColor = true;
            this.finishButton.Click += new System.EventHandler(this.finishButton_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.AutoSize = true;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.fabricPictureLabel, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.fabricPictureBox, 1, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(654, 465);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(394, 201);
            this.tableLayoutPanel2.TabIndex = 6;
            // 
            // fabricPictureLabel
            // 
            this.fabricPictureLabel.AutoSize = true;
            this.fabricPictureLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fabricPictureLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fabricPictureLabel.Location = new System.Drawing.Point(100, 0);
            this.fabricPictureLabel.Name = "fabricPictureLabel";
            this.fabricPictureLabel.Size = new System.Drawing.Size(194, 30);
            this.fabricPictureLabel.TabIndex = 0;
            this.fabricPictureLabel.Text = "Fabric Picture";
            this.fabricPictureLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fabricPictureBox
            // 
            this.fabricPictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fabricPictureBox.Location = new System.Drawing.Point(100, 33);
            this.fabricPictureBox.Name = "fabricPictureBox";
            this.fabricPictureBox.Size = new System.Drawing.Size(194, 165);
            this.fabricPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.fabricPictureBox.TabIndex = 1;
            this.fabricPictureBox.TabStop = false;
            this.fabricPictureBox.Click += new System.EventHandler(this.fabricPictureBox_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.AutoSize = true;
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.modelPictureLabel, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.modelPictureBox, 1, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(128, 465);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(394, 201);
            this.tableLayoutPanel3.TabIndex = 7;
            // 
            // modelPictureLabel
            // 
            this.modelPictureLabel.AutoSize = true;
            this.modelPictureLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.modelPictureLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modelPictureLabel.Location = new System.Drawing.Point(100, 0);
            this.modelPictureLabel.Name = "modelPictureLabel";
            this.modelPictureLabel.Size = new System.Drawing.Size(194, 30);
            this.modelPictureLabel.TabIndex = 0;
            this.modelPictureLabel.Text = "Model Picture";
            this.modelPictureLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // modelPictureBox
            // 
            this.modelPictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.modelPictureBox.Location = new System.Drawing.Point(100, 33);
            this.modelPictureBox.Name = "modelPictureBox";
            this.modelPictureBox.Size = new System.Drawing.Size(194, 165);
            this.modelPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.modelPictureBox.TabIndex = 1;
            this.modelPictureBox.TabStop = false;
            this.modelPictureBox.Click += new System.EventHandler(this.modelPictureBox_Click);
            // 
            // SummaryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1178, 744);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "SummaryForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.SummaryForm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.nameGroupBox.ResumeLayout(false);
            this.nameGroupBox.PerformLayout();
            this.modelNameGroupBox.ResumeLayout(false);
            this.modelNameGroupBox.PerformLayout();
            this.bookingSumGroupBox.ResumeLayout(false);
            this.bookingSumGroupBox.PerformLayout();
            this.orderDateGroupBox.ResumeLayout(false);
            this.orderDateGroupBox.PerformLayout();
            this.fabricNameGroupBox.ResumeLayout(false);
            this.fabricNameGroupBox.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fabricPictureBox)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.modelPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox nameGroupBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.GroupBox modelNameGroupBox;
        private System.Windows.Forms.TextBox modelNameTextBox;
        private System.Windows.Forms.GroupBox bookingSumGroupBox;
        private System.Windows.Forms.TextBox bookingSumTextBox;
        private System.Windows.Forms.GroupBox orderDateGroupBox;
        private System.Windows.Forms.TextBox orderDateTextBox;
        private System.Windows.Forms.GroupBox fabricNameGroupBox;
        private System.Windows.Forms.TextBox fabricNameTextBox;
        private System.Windows.Forms.Button finishButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label fabricPictureLabel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label modelPictureLabel;
        private System.Windows.Forms.PictureBox fabricPictureBox;
        private System.Windows.Forms.PictureBox modelPictureBox;
    }
}